Hi, the way I have built this project gives you two general options:

1 - Run and test the program yourself. To do this, go to SBankProject/out/artifacts and run SBankProject.exe. If it doesn't start up
Command Prompt for you or some equivalent, open command prompt or your equal, go to this location, and run it on that. 

2 - Look at the source code. Take a look at the code quality. Open this project up in an IDE and see how it is structured. I used
IntelliJ IDEA to build all this because it supports scala, but a simple text editor will let you view the objects yourself. Go into
src/com/bank and see everything from there.

Cheers!

-Josh