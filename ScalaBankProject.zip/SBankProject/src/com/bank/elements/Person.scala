/*
Property of Josh Jones 2017
 */

package com.bank.elements


class Person(putId: String, putName: String, putEmail: String, putAddress: String, putAccountType: AccountTypes.Value) {
  protected val id: String = putId
  protected var name: String = putName
  protected var email: String = putEmail
  protected var address: String = putAddress
  protected var balance: Double = 0
  protected var accountType: AccountTypes.Value = putAccountType

  //Adding money to the object
  def addMoney(putAddMoney: Double): Unit = {balance += putAddMoney}

  //Set methods
  def setName(putname: String): Unit = {name = putname}
  def setEmail(putEmail: String): Unit = {email = putEmail}
  def setAddress(putAddress: String): Unit = {address = putAddress}
  def setAccountType(putType: AccountTypes.Value): Unit = {accountType = putType}

  //get methods
  def getId: String = id
  def getMoney: Double = balance
  def getName: String = name
  def getEmail: String = email
  def getAddress: String = address
  def getAccountType: AccountTypes.Value = accountType //effectively returns a string
  override def toString: String = id + ", " + name + ", " + email + ", "+ address + ", £"+ balance + ", "+ accountType + ";"
}
