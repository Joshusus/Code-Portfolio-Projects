/*
Property of Josh Jones 2017
 */

package com.bank.elements

import com.bank.fileHandling.WriteFile
import com.bank.fileHandling.ReadFile
import com.bank.tools.{BasicTools, PersonTools}


class Bank(putBankName: String) {
  /*bankname is a final, and members can be changed throughout an objects existence*/
  val bankName: String = putBankName
  protected var  members:List[Person] = Nil

  //editing members
  def addBalance(putId: String,putMoney: Double): Unit = {

    def generateAddedMoney(hold: List[Person],putId: String,putMoney: Double): Unit = {
      hold match {
        case Nil => Nil
        case x :: xs => if (x.getId.equals(putId)) { x.addMoney(putMoney); println("Done")} else generateAddedMoney(xs,putId,putMoney)
      }
    }
    generateAddedMoney(members,putId,putMoney)

  }

  //adding and removing members
  def addMember(putMember: Person): Unit = {members = putMember::members}
  def addGroupMembers(putMembers: List[Person]): Unit = {members = members ::: putMembers}
  def replaceGroupMembers(PutMembers: List[Person]): Unit = {members = PutMembers}
  def removeMember(putId: String): Unit = {replaceGroupMembers(PersonTools.removeInstances(members, putId))}

  //get methods
  def getMember(putId: String): Person = {
    val position: Int = PersonTools.getIdPosition(members,putId)
    if (position == -1) {null} else members(position)
  }
  def getMember(putPosition: Int): Person = {
    if (putPosition > members.length) {null} else members(putPosition)
  }
  def getMoneyInBank: Double = {BasicTools.addUpDouble(PersonTools.getBalances(members))}
  def getNumberOfMembers: Int = {members.length}
  def getSubscriptionHistogram: String = {
    var holdArray: Array[Int] = Array(0,0,0)

    //Adds to a running list of tallies
    def generateAppend(putType: AccountTypes.Value,holdArray: Array[Int]): Array[Int] ={
      putType match {
        case AccountTypes.Standard => holdArray(0) = holdArray(0) + 1
        case AccountTypes.Premium => holdArray(1) = holdArray(1) + 1
        case AccountTypes.Business => holdArray(2) = holdArray(2) + 1
      }
      holdArray
    }

    //goes through whole members list and adds their type to a running list
    def generateHistogram(hold: List[Person], holdArray: Array[Int]): Array[Int] = {
      hold match {
        case Nil => holdArray
        case x :: xs => generateHistogram(xs, generateAppend(x.getAccountType,holdArray))
      }
    }

   holdArray = generateHistogram(members,holdArray)
    "Standard: " + holdArray(0) + " Premium: " + holdArray(1) +" Business: " + holdArray(2)
  }
  override def toString: String = {
    //gets a simple toString of each member
    def generate(hold: List[Person]): String = {
      hold match {
        case x :: xs => x.getId + "-" + x.getName + "-" + x.getMoney + "," + generate(xs)
        case Nil => ""
      }
    }
    generate(members)
  }

  def writeToFile: Unit = {
    //gets a full toString of each person
    def generate(hold: List[Person]): List[String] = {
      hold match {
        case x :: xs => x.getId + "," + x.getName + "," + x.getEmail + "," + x.getAddress + "," + x.getMoney + "," + x.getAccountType :: generate(xs)
        case Nil => Nil
      }
    }
   val hold = generate(members)
    import com.bank.fileHandling
    WriteFile.write(hold)

  }
  def readFromFile: Unit = {replaceGroupMembers(ReadFile.Read)}
}
