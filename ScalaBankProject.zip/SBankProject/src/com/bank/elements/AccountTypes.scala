/*
Property of Josh Jones 2017
 */

package com.bank.elements

 object AccountTypes extends Enumeration{
  type AccountType = Value
  val Standard, Premium, Business = Value
}
