/*
Property of Josh Jones 2017
 */

package com.bank.fileHandling

import java.io._

object WriteFile {

  /*txt file holds data in a Comma-Seperated-Values format*/
  def write(hold: List[String]): Unit = {
    val p = new java.io.PrintWriter(new File("src/com/bank/files/members.txt"))

    //Writes a single string to file
    def writeToFile(op: java.io.PrintWriter => Unit) {
      try {
        op(p)
      } catch {
        case e: IOException => println("File Not Found. Make sure you are putting your .txt files in .../Code/ ");
        case e: Exception => println("Exception: " + e);
      }
    }

    //Goes through each line and runs the write function on each one
    writeToFile {
      x => hold.foreach(x.println)
    }
    p.close()
  }

  /*
  not used, one should assume that the encryption service is done by a completely
  seperate program, particularly for a bank. Encrypt and decrypt functions would then
  simply reference a long string of all the text to the encrypter and return the
  encrypted text.
  */

  def encrypt(putText: String): String = {
    var wheel5 = 5
    var wheel7 = 7
    var wheel13 = 13
    val values: Array[String] = Array("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", " ")
    var output: String = ""
      for( i <- 0 to putText.length ){

      var tot: Int =  wheel5 * wheel7 *wheel13
        for( b <- values.indices){

        if (putText.substring(i, i + 1) == values(b)) {
          tot += b
          while (tot >= 27) {tot = tot -27}
          output = output + values(tot)
        }

      }
      wheel5 = wheel5 - 1
      wheel7 = wheel7 - 1
      wheel13 = wheel13 - 1
      if (wheel5 == 0) wheel5 = 5
      if (wheel7 == 0) wheel5 = 7
      if (wheel13 == 0) wheel7 = 13
    }

    println(output)
    output
  }
}
