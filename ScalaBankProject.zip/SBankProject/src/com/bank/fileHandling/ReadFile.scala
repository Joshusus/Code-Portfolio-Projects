/*
Property of Josh Jones 2017
 */

package com.bank.fileHandling

import com.bank.elements.{AccountTypes, Person}
import java.io._

object ReadFile {
def Read: List[Person]  = {

  var in: BufferedReader = null
  try {
    var holdPerson = ""
    var holdMembers: List[Person] = Nil
    in = new BufferedReader(new FileReader("src/com/bank/files/members.txt"))
    var n = 0;
    while (holdPerson != null) {

      holdPerson = in.readLine()
      if (holdPerson == null) return holdMembers
      val tempArr = holdPerson.split(",")
      val tempMember = new Person(tempArr(0),tempArr(1),tempArr(2),tempArr(3),  AccountTypes.withName(tempArr(5)))
      tempMember.addMoney(tempArr(4).toDouble)
      holdMembers =  tempMember :: holdMembers
    }
    in.close()
  holdMembers
  }
}
  /*
  not used, one should assume that the encryption service is done by a completely
  seperate program, particularly for a bank. Encrypt and decrypt functions would then
  simply reference a long string of all the text to the encrypter and return the
  encrypted text.
  */
  def decrypt(putCode: String): Unit = {
    var wheel5 = 5
    var wheel7 = 7
    var wheel13 = 13
    val values: Array[String] = Array("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", " ")
  }
}
