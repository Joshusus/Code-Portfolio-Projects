/*
Property of Josh Jones 2017
 */

package com.bank.client

import com.bank.elements.{AccountTypes, Bank, Person}
import com.bank.tools.{BasicTools, PersonTools}
import scala.collection.immutable.List

object Main {

  def main (args: Array[String]): Unit = {

    /*I'll admit, this test object has some really ugly code*/

    var currentBank = new Bank("Goldman Sachs")
    var selectedID: String = "-1"
    var selectedPerson: Person = null
    var selectedList: List[Person] = Nil
    var userInput: String = ""

    //LOOP START

    println("-CommandLine started. This is just an example commandline to demonstrate the rest of the project, and will contain bugs.")

try {
  while (userInput != "quit") {
    userInput = Console.readLine()
    userInput match {

      //Basic commands and selectors
      case "quit" | "exit" => println("-Shutting down") //exit sequence, maybe ask if you want to save
      case "load" | "read" => currentBank.readFromFile; println("-Members loaded")
      case "save" | "write" => currentBank.writeToFile; println("-Members saved")
      case "add member" => currentBank.addMember(createMember(/* generate new id */ "testing")); selectedID = currentBank.getMember(currentBank.getNumberOfMembers - 1).getId;
      case "delete member" => print("ID: "); currentBank.removeMember(Console.readLine); println("any members with specified ID removed")
      case "delete all members" => currentBank.replaceGroupMembers(Nil); println("members list set to Nil")
      case "view all" | "view" => println(currentBank.toString)
      case x if x.startsWith("select ") => if (currentBank.getMember(x.substring(7)) == null) {
        println("-Could not get member");
        selectedID = "-1"
      } else {
        println("-selected " + x.substring(7));
        selectedID = x.substring(7)
      }
      case "clear" => println("_____"); println; println; println; println; println; println; println; println; println; println;
      case "drop" => selectedID = "-1"; println("-Selected member set to Null")
      case "drop group" | "drop list" => selectedList = Nil; println("-holding group set to Nil")
      case "drop all" => selectedID = null; selectedList = Nil; println("-everything selected and holding set to Nil/null")
      case "generate new members" | "generate group" => selectedList = newGroup; println("-Holding a new group of members")
      case "view holding" | "view temp" => print("Person: "); if (selectedID != null && selectedID != "-1") {
        print(currentBank.getMember(selectedID).toString)
      }; print(" List: "); if (selectedList != Nil) {
        print(selectedList)
      }; println;
      case "view group" => if (selectedList != Nil) {
        println(selectedList)
      }
      case "add group" | "place group" => if (selectedList != Nil) {
        currentBank.addGroupMembers(selectedList); println("selected group put into members list")
      } else println("no group selected")

      //Change value of selected object
      case x if x.startsWith("name =") => if (selectedID != null && selectedID != "-1") {
        currentBank.getMember(selectedID).setName(x.substring(7))
      } else error
      case x if x.startsWith("id =") => if (selectedID != null && selectedID != "-1") {
        currentBank.getMember(selectedID).setName(x.substring(7))
      } else error
      case x if x.startsWith("address =") => if (selectedID != null && selectedID != "-1") {
        currentBank.getMember(selectedID).setAddress(x.substring(7))
      } else error
      case x if x.startsWith("email =") => if (selectedID != null && selectedID != "-1") {
        currentBank.getMember(selectedID).setEmail(x.substring(7))
      } else error
      case x if x.startsWith("type =") => if (selectedID != null && selectedID != "-1") {
        currentBank.getMember(selectedID).setAccountType(AccountTypes.withName(x.substring(7)))
      } else error
      case x if x.startsWith("balance +") | x.startsWith("money +") => if (selectedID != null && selectedID != "-1") {
        currentBank.getMember(selectedID).addMoney(x.substring(8).toDouble);
        println("Added £" + x)
      } else error
      case x if x.startsWith("balance -") | x.startsWith("money -") => if (selectedID != null && selectedID != "-1") {
        currentBank.getMember(selectedID).addMoney(("-" + x.substring(8)).toDouble);
        println("Took £" + x)
      } else error

      //reading values of selected object
      case x if x.startsWith("all info") => if (selectedID != null && selectedID != "-1") {
        println(currentBank.getMember(selectedID).toString)
      } else error
      case x if x.startsWith("name") => if (selectedID != null && selectedID != "-1") {
        println(currentBank.getMember(selectedID).getName)
      } else error
      case x if x.startsWith("id") => if (selectedID != null && selectedID != "-1") {
        println(currentBank.getMember(selectedID).getId)
      } else error
      case x if x.startsWith("address") => if (selectedID != null && selectedID != "-1") {
        println(currentBank.getMember(selectedID).getAddress)
      } else error
      case x if x.startsWith("email") => if (selectedID != null && selectedID != "-1") {
        println(currentBank.getMember(selectedID).getEmail)
      } else error
      case x if x.startsWith("type") => if (selectedID != null && selectedID != "-1") {
        println(currentBank.getMember(selectedID).getAccountType)
      } else error
      case x if x.startsWith("balance") | x.startsWith("money") => if (selectedID != null && selectedID != "-1") {
        println("£" + currentBank.getMember(selectedID).getMoney)
      } else error

      //Misc
      case "help" => help
      case x => println("-Unrecognised command")
    }
  } //LOOP END

} catch{
  case e: NullPointerException => println("Null reference exception. Please close and restart program.")
}
  }

  def error: Unit = { println("person / group not selected")}

  /*methods for commands below*/

  def createMember(putID: String): Person = {
    val newPerson = new Person(putID, "UNDEFINED", "UNDEFINED", "UNDEFINED", AccountTypes.Standard)
    print("Name: ")
    newPerson.setName(Console.readLine)
    print("Address: ")
    newPerson.setAddress(Console.readLine)
    print("Email: ")
    newPerson.setEmail(Console.readLine)
    print("Account Type: ")
    newPerson.setAccountType(AccountTypes.withName(Console.readLine))
    newPerson


  }

  def newGroup: List[Person] = {
    val names = List("Mohsin Uppal", "Louis Stanyer", "Josh Jones", "Alex Mackenzie","Matei David","Ciara Lee","Toby Pinn","Sophie Knight","Maddy Tod", "Greta Sugrue","Flo Wragg","Max Waterfall","Teodora Stra","Jimmy Dougan")
  val addresses = List("1 Richmond Hill rd","34 Cuthbert Road","261 Dawlish Road","Flat 42 Liberty Court","Flat 23 Maple Bank","12 Whalley Range","56 Tuffnells Drive")
 val emails = List("christy2@gmail.com","elfabet@hotmail.com","cooldaddy44@virginmedia.com","testemail@student.loreto.ac.uk","realemail@gmail.com")
 val types = List(AccountTypes.Standard,AccountTypes.Business,AccountTypes.Premium)
    import scala.util.Random
    val rng = new Random
    var group: List[Person] = Nil
    for (a <- -1 to (2 + rng.nextInt(4))) {
      val dude = new Person("1",names(rng.nextInt(names.length)), addresses(rng.nextInt(addresses.length)),emails(rng.nextInt(emails.length)), types(rng.nextInt(types.length)))

      dude.addMoney(rng.nextInt(100000).toDouble/100)
     group ::= dude
//println(dude.toString)
    }
    group
  }

  def help: Unit = {
    println("-You own a bank. To load the members written to file for your bank, type 'load'")
    println("-You can also 'hold' a person and a group of people. This lets you add members to your bank.")
    println("-Select a person by typing 'select ' then the ID of the person.")
    println("-There are a number of commands to edit information for people and load/delete info.")
    helpOptions
  }

  def helpOptions: Unit = {
    println("-Type an option: <commands><holding items><files><how to start><back>")
    var input = Console.readLine
    input match {
      case "commands" => println(); commands; helpOptions
      case "holding" | "holding items" => println(); holding; helpOptions
      case "files" => println(); files; helpOptions
      case "how to start" | "how to" => println(); howToStart; helpOptions
      case "back" =>
      case x => println("-Unrecognised command"); helpOptions

      }
    }

  def commands: Unit = {

         println("'quit'/'exit'")
         println("'load'/'read'")
        println("'save'/'write'")
        println("'add member'")
         println("'delete member'")
         println("'delete all members'")
         println("'view'/'view all'")
         println("'select 'X")
         println("'clear'")
         println("'drop'")
         println("'drop group'")
         println("'drop all'")
         println("'generate group'")
         println("'view holding'")
    println("'view group'")
    println("'add group'/'place group'")
 println();
         println("'name = 'X, 'address = 'X, 'email = 'X, 'id = 'X")
         println("'balance + 'X, 'balance -'X")
 println();
         println("'all info'")
         println("'balance','id','name' etc...")

        }

  def holding: Unit = {
          println("You have the choice to hold a person, and seperately a group of people. To hold a person, simply choose the ID of someone")
            println("in the bank, and type 'select ' and then the id of the person. Any details you alter of this person take effect instantly")
          println("are updated in the bank. To hold a group of people, type 'generate group'. To add this group to the bank, type 'add to bank'")
          println("and to replace the bank members with these people; 'replace group'.")

        }

  def files: Unit = {
          println("The members of the bank can be saved to file for access after you close the program. The program WILL NOT read from file")
          println("automatically. To read from file (I suggest you do this at the start), just use the command 'load' or 'read'. To write back")
          println("to file, type 'write'.")
        }

  def howToStart: Unit = {
          println("I suggest the first thing you do when running this interface, is to load the bank members from file by typing 'file'. Next,")
          println("you could add a group of members to the list by typing 'generate group' then 'add group', or you could edit details of an")
          println("existing member by typing 'select ' then his ID, and then maybe typing 'email = joe.bloggs@gmail.com' to edit his email for")
            println("example. To delete the group you're holding or leave the member you have selected, type 'drop group' or 'drop' respectively.")
            println("To finish up, type 'write' to save everything to file. To close the program, type 'exit'.")
        }

}
