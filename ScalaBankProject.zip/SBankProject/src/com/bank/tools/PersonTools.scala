/*
Property of Josh Jones 2017
 */

package com.bank.tools
import com.bank.elements.Person

object PersonTools {
  def setify(people: List[Person]): List[Person] = {
    people match {
      case x :: xs =>  x::setify(removeInstances(xs,  x.getId))
      case Nil => Nil
    }
  }

  def removeInstances(people: List[Person], t: String): List[Person] = {
    people match {
      case x :: xs => if (x.getId.equals(t)){ removeInstances(xs,t) } else { x::removeInstances(xs,t) }
      case Nil => Nil
    }
  }

  def getBalances(people: List[Person]): List[Double] = {
    people match {
      case x :: xs =>  x.getMoney::getBalances(xs)
      case Nil => Nil
    }
  }
  def getGreaterThanXIds(people: List[Person], t: Double): List[String] = {
        people match {
          case x :: xs => if(x.getMoney > t) x.getId::getGreaterThanXIds(xs,t) else getGreaterThanXIds(xs,t)
          case Nil => Nil
    }
  }
  def checkIdExistence(people: List[Person], t: String): Boolean = {
    people match {
      case x :: xs => if(x.getId.equals(t)) true else checkIdExistence(xs,t)
      case Nil => false
    }
  }
  def getIdPosition(people: List[Person], t: String): Int = {
    IdPos(people,t,0)
  }
 private def IdPos(people: List[Person], t: String, n: Int): Int = {
    people match {
      case x :: xs => if(x.getId.equals(t)) n else IdPos(xs,t,n+1)
      case Nil => -1  //Dummy value
    }
  }

}
