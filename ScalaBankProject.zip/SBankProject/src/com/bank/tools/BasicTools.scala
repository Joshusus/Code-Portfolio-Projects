/*
Property of Josh Jones 2017
 */

package com.bank.tools

object BasicTools {
  /*holds some generic functions for us to use*/
 def addUp(hold: List[Int]): Int = {
  hold match {
    case x :: xs => x + addUp(xs)
    case Nil => 0
  }
 }
  def addUpDouble(hold: List[Double]): Double = {
    hold match {
      case x :: xs => x + addUpDouble(xs)
      case Nil => 0
    }
  }

  def average(hold: List[Int]): Double = {
    addUp(hold).toDouble/hold.length.toDouble
    }
  def averageDouble(hold: List[Double]): Double = {
    addUpDouble(hold)/hold.length.toDouble
  }
}
