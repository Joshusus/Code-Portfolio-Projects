  Evolve is a small game I made in 2016. It was more of a scientific, proof-of-concept simulation that 
shows off various theoretical Artificial Intelligence concepts. In some ways, this was a very simple
prototype of the AI I created working for Salvage from 2016-2017. 

	Keybindings:
(All keybindings are on the numpad and arrow keys)

-Numpad 4,8,6,3 move you around the map.
-Numpad 5 feeds all living cells 1 food point.
-Arrow up, down let you scroll through various world conditions (wind, gravity, wetness etc)
-Arrow left, right let you alter the selected world condition.

The map doesnt have visually defined boundaries, but they are
there and you can see your coordinates at the bottom of the screen. 

	Rules:

# The game starts with 1 cell, and the map is populated with 50 plants (max number).
# Once a cell has eaten enough plants/other cells, he will reproduce, and a duplicate cell will appear
somewhere else on the map.
# Plants reproduce over time. Their offspring will appear somewhere near them. 

	Sounds simple right? Not quite:

- Cells have 4 stats: Health, Reproduce, Attack, Speed.
- Occasionally when a cell reproduces, its offspring will have slightly different stats to its parent.
- Different stats obviously mean a cell will be better at different things. A high reproduce cell will 
have to eat less food to reproduce, or a low attack cell will deal less damage when fighting.
- A cell is constantly deciding what to do. Eat this plant here? Run away from this cell? Chase this
weaker cell over here?
- Different stats are better in different enviroments. Play with the enviroment conditions and see what 
happens to the average stats of all the cells.
- Both cells and plants are affected in different ways to the enviroment. 

Experiment and enjoy!
-Josh Jones
