	Space Physics

  Just as a note, this game is not in a state where I would officially release it so expect for a lot
of crashes if you try and test the program. This is more of a problem on menu screens to be honest. I 
was a bit rushed on them when I made the program. (Eg: DONT RUN THE TUTORIAL OPTION)

Space Physics is a wonderful little game, regardless of mentioned bugs though.

Quick mini keybindings (can find out all of them in menu screen upon startup):
If keybindings not working, press num lock and try again.

Numpad 1-9 are movement keys. 5 is brake. 
Numpad / uses module 1. (Upon game start this is a carbon gun)
Numpad * uses module 2. (Empty upon start)
Numpad . uses lightspeed (Must be travelling fast and have enough power)
Numpad + uses grapple. (Must be near object, use this to mine asteroids)


				MENU
				 |
				 V
			  Space Simulator <-\
				 |	    |
				 V          |
			/->Galactical Map --/
			|        |
			|        V
			\---Ship Screen 


Enjoy exploring the game universe! There is a spacestation in the sector just right of where you start
off. Grapple onto it to dock and enter. You can trade and upgrade your ship from there.

Thanks!
-Josh Jones

